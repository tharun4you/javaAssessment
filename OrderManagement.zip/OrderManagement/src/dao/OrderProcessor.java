package dao;
import java.sql.*;
import entity.User;
import entity.order;
import exception.UserNotFoundException;
import exception.OrderNotFoundException;
import entity.Product;
import util.DBConnUtil;
import java.util.List;
public class OrderProcessor extends IOrderManagementRepository{

	private Connection con;
	PreparedStatement s;
	
	public OrderProcessor(){
	     con= DBConnUtil.getDBConn();
	}
	
	@Override
	public void createOrder(order o)
	{
		try 
		{
			s=con.prepareStatement("insert into orders (orderId,userId,productId) values (?,?,?)");
			s.setInt(1,o.getOrderId());
			s.setInt(2, o.getUserId());
			s.setInt(3, o.getProductId());
			s.executeUpdate();
		} 
		catch (SQLException e) 
		{
			System.out.println(e.getMessage());
		}
		
	}

	@Override
	public void cancelOrder(int orderId) throws OrderNotFoundException {
		try 
		{
			boolean b=false;
			s=con.prepareStatement("delete from orders where orderid=?");
			s.setInt(1, orderId);
		    s.executeUpdate();
			if(!b) 
			{
				throw new OrderNotFoundException("Order ID not found");
				
			}
		} 
		catch (SQLException e) 
		{
			System.out.println("The entered is Order ID not found!"+e.getMessage());
		}	
	}

	@Override
	public void createProduct(Product p) 
	{
		try 
		{
			s=con.prepareStatement("insert into product (productId,productName,description,price,quantityInStock,type) values (?,?,?,?,?,?)");
			s.setInt(1, p.getProductId());
			s.setString(2,p.getProductName());
			s.setString(3,p.getDescription());
			s.setDouble(4,p.getPrice());
			s.setInt(5, p.getQuantityInStock());
			s.setString(6,p.getType());
			s.executeUpdate();
		} 
		catch (SQLException e) 
		{
			System.out.println(e.getMessage());
		}
	}

	@Override
	public void createUser(User u) 
	{
		try {
			s=con.prepareStatement("insert into user (userId,userName,password,role) values (?,?,?,?)");
			s.setInt(1, u.getUserId());
			s.setString(2,u.getUsername());
			s.setString(3,u.getPassword());
			s.setString(4,u.getRole());
			s.executeUpdate();
		} 
		catch (SQLException e) {
			System.out.println(e.getMessage());
		}
	}

	@Override
	public void getAllProducts() 
	{
		try 
		{
			
			s=con.prepareStatement("select * from product");
			ResultSet r=s.executeQuery();
			while(r.next()){
            System.out.print("Product_ID: "+r.getInt(1)+" "+"Product_Name:"+r.getString(2)+" "+"Description:"+" "+r.getString(3)+" "+"Price:"+" "+r.getInt(4)+" "+"Quantity:"+" "+r.getInt(5)+" "+"Type:"+" "+r.getString(6));
            System.out.println();
            System.out.println();
			}
		} 
		catch (SQLException e) 
		{
			System.out.println(e.getMessage());
		}
		
	}

	@Override
	public void getOrderByUser(int userId) throws UserNotFoundException {
		try 
		{
			
			s=con.prepareStatement("select * from orders where userid= ?");
			s.setInt(1, userId);
			ResultSet r=s.executeQuery();
			while(r.next()){
            System.out.print("OrderID: "+r.getInt(1)+" "+" UserID:"+r.getInt(2)+" "+" ProductID:"+" "+r.getInt(3));
            System.out.println();
            System.out.println();
			}
		} 
		catch (SQLException e) 
		{
			System.out.println(e.getMessage());
		}
	    
	}
}
