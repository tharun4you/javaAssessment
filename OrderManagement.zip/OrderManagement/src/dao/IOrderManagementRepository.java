package dao;
import entity.User;
import exception.OrderNotFoundException;
import exception.UserNotFoundException;
import entity.Product;
import entity.order;


public abstract class IOrderManagementRepository {
	abstract void createOrder(order o);
	
	abstract void cancelOrder(int orderId) throws OrderNotFoundException;
	abstract void createProduct(Product p);
	abstract void createUser(User u);
	abstract void getAllProducts();
	abstract void getOrderByUser(int Userid) throws UserNotFoundException;
}