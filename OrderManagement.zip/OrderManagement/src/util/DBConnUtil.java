package util;
import java.sql.*;

public class DBConnUtil {
	private static Connection connection = null;
	
	DBConnUtil() {
     try {
            
            Class.forName("com.mysql.cj.jdbc.Driver");
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/ OrderManagement", "root", "Tharunsql@2003");
        }
        catch(Exception e)
        {
        	System.out.println(e);
        }
	}
	public static Connection getDBConn()
	 {
		DBConnUtil o= new DBConnUtil();
		 return connection;
	 }
}