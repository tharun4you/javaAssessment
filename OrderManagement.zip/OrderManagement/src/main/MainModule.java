package main;
import dao.IOrderManagementRepository;
import dao.OrderProcessor;
import entity.User;
import entity.Product;
import java.util.List;
import java.util.*;

public class MainModule {
	public static void main(String args[]) {
		Scanner sc=new Scanner(System.in);
		service obj=new service();
		
		
		while(true)
		{
			System.out.println("1 -> Create user ");
			System.out.println("2 -> Create product ");
			System.out.println("3 -> Display product ");
			System.out.println("4 -> Create order ");
			System.out.println("5 -> Get product by user");
			System.out.println("6 -> Cancel order ");
			System.out.println("7 -> Exit");
			
			
			System.out.println("Enter your choice:");
			int ch=sc.nextInt();
			if(ch==1)
			{
				obj.createUser();
			}
			else if(ch==2)
			{
				obj.creatProduct();
			}
			else if(ch==3)
			{
				obj.getAllProducts();
			}
			else if(ch==4)
			{
				obj.createOrder();;
			}
			else if(ch==5)
			{
				obj.getorderByuser();
			}
			else if(ch==6)
			{
				obj.cancelOrder();
			}
			else if(ch==7)
			{
				break;
			}
		}
	}
		
	}