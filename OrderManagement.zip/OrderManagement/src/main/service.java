package main;
import dao.IOrderManagementRepository;
import dao.OrderProcessor;
import entity.User;
import entity.order;
import exception.OrderNotFoundException;
import exception.UserNotFoundException;
import entity.Product;
import java.util.List;
import java.util.*;

public class service {
		
		Scanner sc=new Scanner(System.in);
		OrderProcessor od=new OrderProcessor();

		public void createOrder()
		{
			order o=new order();
			System.out.println("Enter order id :");
			o.setOrderId(sc.nextInt());
			System.out.println("Enter user ID :");
			o.setUserId(sc.nextInt());
			System.out.println("Enter product ID :");
			o.setProductId(sc.nextInt());
			od.createOrder(o);
		}
		
		public void cancelOrder()
		{
			order o=new order();
			System.out.println("Enter order id  to be calcelled :");
			int orderid=sc.nextInt();
		    try {
				od.cancelOrder(orderid);
			} 
		    catch (OrderNotFoundException e) {
				e.getMessage();
			}
		}
		public void creatProduct()
		{
			Product p=new Product();
			System.out.println("Enter product ID :");
			p.setProductId(sc.nextInt());
			System.out.println("Enter product name :");
			sc.nextLine();
			p.setProductName(sc.nextLine());
			System.out.println("Enter product description :");
			p.setDescription(sc.nextLine());
			System.out.println("Enter price :");
			p.setPrice(sc.nextDouble());
			System.out.println("Enter quantity in stock :");
			p.setQuantityInStock(sc.nextInt());
			System.out.println("Enter type either Clothing or Electronics :");
			sc.nextLine();
			p.setType(sc.nextLine());
			
			od.createProduct(p);
		}
		
		public void createUser()
		{
			User u=new User();
			System.out.println("Enter user ID :");
			u.setUserId(sc.nextInt());
			System.out.println("Enter User name :");
			sc.nextLine();
			u.setUsername(sc.nextLine());
			System.out.println("Enter Password :");
			u.setPassword(sc.nextLine());
			System.out.println("Enter role either Admin or User :");
			u.setRole(sc.nextLine());
			od.createUser(u);
		}
		
		public void getAllProducts()
		{
			od.getAllProducts();
		}
		public void getorderByuser() 
		{
			System.out.println("Enter user ID to get product order:");
			int userid=sc.nextInt();
			try {
				od.getOrderByUser(userid);
			} 
			catch (UserNotFoundException e) 
			{
				e.printStackTrace();
			}
			
		}
	}
