package conn;
import java.util.*;
import java.sql.*;

public class Mainn {
	public static void main(String[]args) {
	Connection conn = null;
    try {
         Class.forName("com.mysql.cj.jdbc.Driver");
         conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/tharun", "root", "Tharunsql@2003");
         System.out.println("Connected to the database");
        }
    catch(Exception e)
        {
       	System.out.println(e);
        }
	}
}