package conn;
import java.util.*;
import java.sql.*;

public class Main {
	Connection conn = null;
    try {
         Class.forName("com.mysql.cj.jdbc.Driver");
         conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/jdbc", "root", "root");
         System.out.println("Connected to the database");
        }
    catch(Exception e)
        {
       	System.out.println(e);
        }
}